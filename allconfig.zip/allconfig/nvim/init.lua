-- ====================================
-- 基础设置
-- ====================================
vim.opt.showtabline = 2          -- 总是显示标签页
vim.opt.number = true            -- 显示行号
vim.opt.cursorline = true        -- 高亮当前行
vim.opt.termguicolors = true     -- 真彩色支持
vim.opt.signcolumn = "yes"       -- 始终显示符号列
vim.opt.syntax = "enable"        -- 语法高亮
vim.opt.ignorecase = true        -- 搜索忽略大小写
vim.opt.smartcase = true         -- 智能大小写
vim.opt.wrap = false             -- 不自动换行
vim.opt.clipboard:append("unnamedplus") -- 系统剪贴板
vim.opt.tabstop = 4              -- 制表符空格数
vim.opt.shiftwidth = 4           -- 自动缩进空格数
vim.opt.autoindent = true        -- 自动缩进
vim.opt.smartindent = true       -- 智能缩进
vim.opt.expandtab = true         -- 制表符转空格
vim.opt.mouse:append("a")        -- 鼠标支持
vim.opt.wildmenu = true          -- 命令补全菜单
vim.opt.encoding = "utf-8"       -- 编码设置
vim.opt.fileencoding = "utf-8"
vim.opt.undofile = true          -- 持久撤销
vim.opt.swapfile = true          -- 交换文件
--vim.opt.backup = true            -- 备份文件
vim.opt.updatetime = 300         -- 更新间隔
vim.opt.timeoutlen = 500         -- 按键超时
vim.opt.splitright = true        -- 垂直分割右侧打开
vim.opt.splitbelow = true        -- 水平分割下方打开
vim.opt.filetype = "on"          -- 文件类型检测

-- 显示错误信息
vim.o.mousemoveevent = true     -- 鼠标悬停显示变量信息
vim.api.nvim_create_autocmd("CursorHold", {
  callback = function()
    local opts = {
      focusable = false,
      close_events = { "CursorMoved", "CursorMovedI", "BufHidden", "InsertCharPre" },
      border = 'rounded',
      source = 'always',
      prefix = ' ',
      scope = 'cursor',
    }
    vim.diagnostic.open_float(nil, opts)
  end
})

-- 按键绑定
-- ====================================
-- 基本键位
vim.keymap.set("i", "qq", "<ESC>")               -- 插入模式下qq退出插入模式
vim.keymap.set("n", " ", ":nohlsearch<CR>")      -- 空格取消搜索高亮
vim.keymap.set("n", "=", ":!go run %<CR>")       -- 运行当前Go文件
vim.keymap.set('n', '<F9>', ':NvimTreeToggle<CR>') -- 切换文件树

-- 实用快捷键
vim.keymap.set('n', '<leader>w', ':w<CR>', { desc = '保存文件' })
vim.keymap.set('n', '<leader>q', ':q<CR>', { desc = '退出' })
vim.keymap.set('n', '<leader>e', ':NvimTreeFocus<CR>', { desc = '聚焦文件树' })
vim.keymap.set('n', '<C-h>', '<C-w>h', { desc = '左窗口' })
vim.keymap.set('n', '<C-j>', '<C-w>j', { desc = '下窗口' })
vim.keymap.set('n', '<C-S-k>', '<C-w>k', { desc = '上窗口' })
vim.keymap.set('n', '<C-l>', '<C-w>l', { desc = '右窗口' })
-- ====================================
-- 在普通模式下，将F7键映射为启动Markdown预览的命令
vim.keymap.set('n', '<F7>', ':MarkdownPreviewToggle<CR>', { 
  noremap = true, silent = true, 
  desc = '切换 Markdown 预览（启动/关闭）' -- 描述更新为“切换”，更准确
})

-- 插件配置
-- ====================================
require("plugins.plugins-setup")  -- 加载插件管理配置


-- 启用并配置 smear-cursor.nvim（光标动画插件）
require('smear_cursor').setup({
  -- 与你的 tokyodark 主题配色协调
  cursor_color = "#7aa2f7", -- 光标颜色（复用标签页选中文字色，保持统一）
  transparent_bg_fallback_color = "#1a1b26", -- 匹配主题背景色
  normal_bg = "#1a1b26", -- 正常模式背景色（与主题一致）

  -- 动画参数（平衡流畅度与视觉干扰）
  stiffness = 0.6, -- 光标移动的"弹性"（默认0.6，值越大越紧凑）
  damping = 0.85, -- 动画衰减速度（值越小拖影越长）
  max_length = 20, -- 正常模式拖影长度（适中，避免过长遮挡）
  max_length_insert_mode = 5, -- 插入模式缩短拖影，不干扰输入

  -- 多光标插件（vim-visual-multi）兼容
  never_draw_over_target = true, -- 不覆盖多光标选中区域
  smear_between_buffers = true, -- 切换缓冲区时仍显示动画

  -- 模式适配
  smear_insert_mode = true, -- 插入模式启用动画
  stiffness_insert_mode = 0.7, -- 插入模式动画更"硬"，响应更快
  time_interval = 15, -- 15ms 帧率（≈66帧，比默认更流畅）
})

-- 多光标模式下优化光标动画（减少干扰）
vim.api.nvim_create_autocmd("User", {
  pattern = "VisualMultiStart", -- 进入多光标模式时触发
  callback = function()
    require('smear_cursor').update_config({
      max_length = 5, -- 缩短拖影
      stiffness = 0.9 -- 加快动画速度
    })
  end
})

vim.api.nvim_create_autocmd("User", {
  pattern = "VisualMultiEnd", -- 退出多光标模式时触发
  callback = function()
    require('smear_cursor').update_config({
      max_length = 20, -- 恢复默认拖影长度
      stiffness = 0.6 -- 恢复默认动画
    })
  end
})

-- 主题设置
vim.cmd('colorscheme tokyodark')


-- 代码文档悬停
local opts = { noremap=true, silent=true }
vim.keymap.set('n', '<S-K>', '<cmd>lua vim.lsp.buf.hover()<CR>', opts)

-- 注释插件
require('Comment').setup()

-- 禁用netrw
vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1

-- 文件树配置
require("nvim-tree").setup({
    view = {
        width = 30,
        side = "left",
    },
    renderer = {
        highlight_git = true,
        icons = {
            show = {
                git = true,
                folder = true,
                file = true,
            },
            glyphs = {
                default = "",
                symlink = "",
                git = {
                    unstaged = "",
                    staged = "✓",
                    unmerged = "",
                    renamed = "➜",
                    untracked = "",
                    deleted = "",
                    ignored = "◌",
                },
            },
        },
    },
    filters = {
        dotfiles = false,
    },
})
-- barbar.nvim 标签页配置（核心新增）
-- ====================================
require('bufferline').setup({
  options = {
    -- 图标已解决，直接启用
    icon_enabled = true,
    -- 标签页样式：细分隔符，简洁不拥挤
    separator_style = 'none',
    -- 关闭/修改标记图标（贴合主题风格）
    close_icon = '',
    modified_icon = '●',
    left_trunc_marker = '',
    right_trunc_marker = '',
    -- 标签页尺寸适配（避免文件名过长/过短）
    max_name_length = 18,
    max_prefix_length = 15,
    tab_size = 20,
    -- 始终显示标签栏（即使只有1个文件）
    always_show_bufferline = true,
    -- 按打开顺序排序（符合直觉）
    sort_by = 'insert_after_current',
    -- 过滤冗余标签页（不显示文件树、帮助文档等）
    exclude_ft = { 'qf', 'help', 'man', 'git', 'neo-tree' },
    exclude_name = { 'go.mod', 'go.sum', 'package.json' },
    -- 鼠标支持（你的配置已启用鼠标，适配点击/滚轮）
    mousewheel = true,
    -- 右侧新增标签页按钮（可视化操作）
    custom_areas = {
      right = function()
        local result = {}
        table.insert(result, { text = '    ', cmd = 'tabnew' })
        return result
      end,
    },
  },
  })
-- ====================================
-- barbar.nvim 快捷键（贴合你的现有习惯，无需新记）
-- ====================================
local keymap = vim.keymap.set
local opts = { noremap = true, silent = true, desc = '' }

-- 1. 核心切换：Alt+左/右 箭头（和你之前的缓冲区切换逻辑一致）
opts.desc = '切换到上一个标签页'
keymap('n', '<A-h>', '<Cmd>BufferPrevious<CR>', opts)
opts.desc = '切换到下一个标签页'
keymap('n', '<A-l>', '<Cmd>BufferNext<CR>', opts)

-- 2. 快速跳转：直接跳转到第1-3个标签页（多文件时用）
opts.desc = '跳转到第1个标签页'
keymap('n', '<leader>1', '<Cmd>BufferGoto 1<CR>', opts)
opts.desc = '跳转到第2个标签页'
keymap('n', '<leader>2', '<Cmd>BufferGoto 2<CR>', opts)
opts.desc = '跳转到第3个标签页'
keymap('n', '<leader>3', '<Cmd>BufferGoto 3<CR>', opts)
opts.desc = '跳转到第4个标签页'
keymap('n', '<leader>4', '<Cmd>BufferGoto 3<CR>', opts)
opts.desc = '跳转到第5个标签页'
keymap('n', '<leader>5', '<Cmd>BufferGoto 3<CR>', opts)

-- 3. 标签页操作：复用你的 <leader>ft/<leader>dt 快捷键
opts.desc = '新建标签页'
keymap('n', '<leader>ft', '<Cmd>tabnew<CR>', opts) -- 和你原有新建快捷键一致
opts.desc = '关闭当前标签页'
keymap('n', '<leader>dt', '<Cmd>BufferClose<CR>', opts) -- 和你原有关闭快捷键一致
opts.desc = '强制关闭当前标签页（不保存）'
keymap('n', '<leader>dT', '<Cmd>BufferClose!<CR>', opts)

-- 4. 标签页搜索：多文件时快速筛选（新增，实用功能）
opts.desc = '模糊搜索标签页'
keymap('n', '<leader>bs', '<Cmd>BufferPick<CR>', opts)

-- ====================================
-- LSP配置（你的原有配置，无需修改）
require'mason'.setup{}
require'mason-lspconfig'.setup{
    ensure_installed = {
        'jdtls',     -- Java语言服务器
        'gopls',     -- Go
        'pyright',   -- Python
        'clangd',    -- C/C++
        'html',      -- HTML
        'denols',    -- JavaScript/TypeScript
        'yamlls',    -- YAML
        'cssls'      -- CSS
    },
    automatic_installation = true
}


-- ====================================
-- LSP配置
-- ====================================
require'mason'.setup{}
require'mason-lspconfig'.setup{
    ensure_installed = {
        'jdtls',     -- Java语言服务器
        'gopls',     -- Go
        'pyright',   -- Python
        'clangd',    -- C/C++
        'html',      -- HTML
        'denols',    -- JavaScript/TypeScript
        'yamlls',    -- YAML
        'cssls'      -- CSS
    },
    automatic_installation = true
}

local lspconfig = require'lspconfig'
local cmp_nvim_lsp = require('cmp_nvim_lsp')

-- 通用LSP配置
local on_attach = function(client, bufnr)
    local bufopts = { noremap=true, silent=true, buffer=bufnr }
    
    vim.keymap.set('n', 'gD', vim.lsp.buf.declaration, bufopts)
    vim.keymap.set('n', 'gd', vim.lsp.buf.definition, bufopts)
    vim.keymap.set('n', 'K', vim.lsp.buf.hover, bufopts)
    vim.keymap.set('n', 'gi', vim.lsp.buf.implementation, bufopts)
    vim.keymap.set('n', '<C-k>', vim.lsp.buf.signature_help, bufopts)
    vim.keymap.set('n', '<leader>rn', vim.lsp.buf.rename, bufopts)
    vim.keymap.set('n', '<leader>ca', vim.lsp.buf.code_action, bufopts)
    vim.keymap.set('n', 'gr', vim.lsp.buf.references, bufopts)
    vim.keymap.set('n', '<leader>f', function() vim.lsp.buf.format { async = true } end, bufopts)
end

local lsp_flags = {
    debounce_text_changes = 150,
}

-- 配置各语言服务器(除Java外)
local servers = {
    'gopls', 'pyright', 'clangd', 'html', 'denols', 'yamlls', 'cssls'
}
-- 单独配置Java LSP（简化版）
lspconfig.jdtls.setup {
    on_attach = on_attach,
    flags = lsp_flags,
    capabilities = cmp_nvim_lsp.default_capabilities(),
    -- Java项目需要根目录检测
    root_dir = function(fname)
        return lspconfig.util.root_pattern('pom.xml', 'gradle.build', '.git')(fname) or
               lspconfig.util.path.dirname(fname)
    end,
}

-- 为每个服务器单独配置（除jdtls外）
for _, lsp in ipairs(servers) do
    lspconfig[lsp].setup {
        on_attach = on_attach,
        flags = lsp_flags,
        capabilities = cmp_nvim_lsp.default_capabilities()
    }
end

-- ====================================

-- ====================================
-- 代码补全配置
-- ====================================
local cmp = require'cmp'
local luasnip = require'luasnip'

cmp.setup({
    snippet = {
        expand = function(args)
            luasnip.lsp_expand(args.body)
        end,
    },
    mapping = cmp.mapping.preset.insert({
        ['<C-b>'] = cmp.mapping.scroll_docs(-4),
        ['<C-f>'] = cmp.mapping.scroll_docs(4),
        ['<C-Space>'] = cmp.mapping.complete(),
        ['<C-e>'] = cmp.mapping.abort(),
        ['<CR>'] = cmp.mapping.confirm({ select = true }),
        ['<Tab>'] = cmp.mapping(function(fallback)
            if cmp.visible() then
                cmp.select_next_item()
            elseif luasnip.expand_or_jumpable() then
                luasnip.expand_or_jump()
            else
                fallback()
            end
        end, { 'i', 's' }),
        ['<S-Tab>'] = cmp.mapping(function(fallback)
            if cmp.visible() then
                cmp.select_prev_item()
            elseif luasnip.jumpable(-1) then
                luasnip.jump(-1)
            else
                fallback()
            end
        end, { 'i', 's' })
    }),
    sources = cmp.config.sources({
        { name = 'nvim_lsp' },
        { name = 'luasnip' },
        { name = 'buffer' },
        { name = 'path' },
    }),
    window = {
        completion = cmp.config.window.bordered({
            border = 'rounded',
            winhighlight = "Normal:Normal,FloatBorder:FloatBorder,CursorLine:Visual,Search:None",
        }),
        documentation = cmp.config.window.bordered({
            border = 'rounded',
            winhighlight = "Normal:Normal,FloatBorder:FloatBorder,CursorLine:Visual,Search:None",
        }),
    },
    formatting = {
        fields = {'menu', 'abbr', 'kind'},
        format = function(entry, vim_item)
            vim_item.menu = ({
                nvim_lsp = '[LSP]',
                luasnip = '[Snippet]',
                buffer = '[Buffer]',
                path = '[Path]',
            })[entry.source.name]
            return vim_item
        end,
    }
})

-- ====================================
-- 颜色设置
-- ====================================
-- 调整补全菜单的颜色
vim.api.nvim_set_hl(0, 'CmpItemKind', { fg = '#7aa2f7' })
vim.api.nvim_set_hl(0, 'CmpItemAbbr', { fg = '#c0caf5' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatch', { fg = '#bb9af7', bold = true })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchFuzzy', { fg = '#bb9af7', bold = true })
vim.api.nvim_set_hl(0, 'CmpItemMenu', { fg = '#565f89' })
-- 调整选中项的颜色
vim.api.nvim_set_hl(0, 'CmpItemKindDefault', { fg = '#7aa2f7', bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrDefault', { fg = '#c0caf5', bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchDefault', { fg = '#bb9af7', bold = true, bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchFuzzyDefault', { fg = '#bb9af7', bold = true, bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemMenuDefault', { fg = '#565f89', bg = '#1a1b26' })
-- 设置正常状态下的状态栏颜色
vim.api.nvim_set_hl(0, 'StatusLine', {
    bg = '#26233a',  -- 与未选中标签页背景色相近，保持协调
    fg = '#eb6f92',  -- 与选中标签页文本强调色相近，突出显示
    bold = true      -- 文字加粗，增强视觉效果
})
-- 设置非当前窗口的状态栏颜色
vim.api.nvim_set_hl(0, 'StatusLineNC', {
    bg = '#1a1b26',  -- 与标签页填充部分背景色相同，统一整体风格
    fg = '#565f89'   -- 较暗的中性色，弱化非当前窗口状态栏
})
-- 设置注释的颜色
vim.api.nvim_set_hl(0, 'Comment', { fg = '#D4C9A5', italic = true })
-- ====================================
-- 自动命令
-- ====================================
local autocmd = vim.api.nvim_create_autocmd

-- 保存时自动格式化
autocmd('BufWritePre', {
    pattern = '*',
    callback = function()
        vim.lsp.buf.format({ async = false })
    end,
})

-- 文件类型特定设置
autocmd('FileType', {
    pattern = { 'python', 'go', 'java' },
    callback = function()
        vim.opt_local.shiftwidth = 4
        vim.opt_local.tabstop = 4
        if vim.bo.filetype == 'java' then
            vim.opt_local.cindent = true
            vim.opt_local.foldmethod = "marker"
        end
    end,
})


-- ===========================================

--配置弹出式命令菜单 wilder
local wilder = require('wilder')
wilder.setup({ modes = { ':', '/', '?' } })

-- 定义暗色背景高亮组
 vim.api.nvim_set_hl(0, 'WilderMenu', { bg = '#282c34', fg = '#ffffff' })
 vim.api.nvim_set_hl(0, 'WilderMenuSelected', { bg = '#3b4048', fg = '#ffffff' })
 vim.api.nvim_set_hl(0, 'WilderMenuAccent', { bg = '#282c34', fg = '#61afef' })
-- 设置边框高亮组，确保背景色与菜单背景色一致
vim.api.nvim_set_hl(0, 'WilderBorder', { bg = '#282c34', fg = '#555555' })

-- 设置
wilder.set_option('renderer', wilder.popupmenu_renderer(
  wilder.popupmenu_border_theme({
    highlights = {
      border = 'Normal', -- 用于边框的高亮
      menu = 'WilderMenu', -- 菜单背景的高亮
      selected = 'WilderMenuSelected', -- 选中项背景的高亮
      accent = 'WilderMenuAccent', -- 强调文本的高亮
    },
    -- 'single', 'double', 'rounded' or 'solid'
    -- 也可以是一个包含8个字符的列表，详见 :h wilder#popupmenu_border_theme()
    border = 'rounded',
  })
))

-- =============================================

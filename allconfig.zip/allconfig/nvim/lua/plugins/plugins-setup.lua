local ensure_packer = function()
  local fn = vim.fn
  local install_path = fn.stdpath('data')..'/site/pack/packer/start/packer.nvim'
  if fn.empty(fn.glob(install_path)) > 0 then
    -- 使用镜像源克隆 packer.nvim
    fn.system({'git', 'clone', '--depth', '1', 'https://github.com.cnpmjs.org/wbthomason/packer.nvim', install_path})
    vim.cmd [[packadd packer.nvim]]
    return true
  end
  return false
end

local packer_bootstrap = ensure_packer()

return require('packer').startup(function(use)
    -- 设置 GitHub 镜像源（自动替换 github.com 为 github.com.cnpmjs.org，加速下载）
    local github_proxy = "https://github.com.cnpmjs.org/"
    local original_use = use
    use = function(spec)
        if type(spec) == 'string' then
            spec = { spec }
        end
        if spec[1]:find('github.com') then
            spec[1] = spec[1]:gsub('github.com', 'github.com.cnpmjs.org')
        end
        original_use(spec)
    end

    -- 插件管理器核心
    use 'wbthomason/packer.nvim' 
    -- 主题插件（保留原有所有主题）
    use { "tiagovla/tokyodark.nvim" } 
    use {"rose-pine/neovim"}
    use {"catppuccin/nvim",name="catppuccin",priority=1000,opts = {flavour="frappe",transparent_background = true }}
    -- 文件树（保留）
    use 'nvim-tree/nvim-tree.lua' 
    -- 缩进线（保留）
    use 'yaocccc/nvim-hlchunk' 
    -- Go 开发插件（保留）
    use 'fatih/vim-go' 
    -- 代码跳转（保留）
    use {'nvim-telescope/telescope.nvim', tag = '0.1.5',requires = { {'nvim-lua/plenary.nvim'} } }
    -- 符号补全（保留）
    use 'jiangmiao/auto-pairs' 
    -- 注释插件（保留）
    use 'numToStr/Comment.nvim' 
    -- 多光标插件（保留）
    use 'mg979/vim-visual-multi' 
    -- 光标移动动画
    use 'sphamba/smear-cursor.nvim'
    -- 【关键修改】替换为 markdown-preview.nvim（无需 Rust 编译，Node 依赖自动安装）
    use 'iamcco/markdown-preview.nvim'
    -- 命令菜单增强（保留）
    use {"gelguy/wilder.nvim",config = function()require('wilder').setup({ modes = { ':', '/', '?' } })end}
    -- 标签
    use 'romgrk/barbar.nvim'
    --ico 
    use { 'nvim-tree/nvim-web-devicons', config = function()require('nvim-web-devicons').setup({ default = true })end }
    -- LSP 相关插件（保留原有三件套）
    use {
        'williamboman/mason.nvim', -- LSP 服务器管理
        'williamboman/mason-lspconfig.nvim', -- 连接 mason 和 nvim-lspconfig
        'neovim/nvim-lspconfig', -- LSP 核心配置
    }
    -- 代码补全相关插件（保留原有所有）
    use 'hrsh7th/cmp-nvim-lsp' -- LSP 补全支持
    use 'hrsh7th/nvim-cmp' -- 补全核心
    use 'hrsh7th/cmp-buffer' -- 缓冲区补全
    use 'hrsh7th/cmp-path' -- 路径补全
    use 'saadparwaiz1/cmp_luasnip' -- 代码片段补全
    use 'L3MON4D3/LuaSnip' -- 代码片段核心

    -- 首次安装 Packer 时自动同步插件（保留）
    if packer_bootstrap then
        require('packer').sync()
    end
end)
